package AirPlane.model;

public enum AirplaneState {
    ENGINE_OFF, ENGINE_ON, FLYING, EXPLODED;
}