package AirPlane.model.Exception;

public class AirplaneAlreadyStartedException extends AirplaneException{
    public AirplaneAlreadyStartedException(String message){
        super(message);
    }
}
