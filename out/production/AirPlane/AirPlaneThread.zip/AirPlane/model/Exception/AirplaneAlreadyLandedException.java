package AirPlane.model.Exception;

public class AirplaneAlreadyLandedException extends AirplaneException{
    public AirplaneAlreadyLandedException(String message){
        super(message);
    }
}
