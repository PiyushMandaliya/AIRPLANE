package AirPlane.model.Exception;

public class AirplaneIsLandedException extends AirplaneException {
    public AirplaneIsLandedException(String message) {
        super(message);
    }

    public AirplaneIsLandedException() {
        super();
    }
}
