package AirPlane.model.Exception;

public class AirplaneFlyingException extends AirplaneException{
    public AirplaneFlyingException(String message) {
        super(message);
    }
}
