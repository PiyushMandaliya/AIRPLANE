package AirPlane.model.Exception;

public class AirplaneCannotStopInAirException extends AirplaneException {
    public AirplaneCannotStopInAirException(String message) {
        super(message);
    }
}
