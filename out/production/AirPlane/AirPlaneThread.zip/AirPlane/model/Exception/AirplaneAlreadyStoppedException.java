package AirPlane.model.Exception;

public class AirplaneAlreadyStoppedException extends AirplaneException{
    public AirplaneAlreadyStoppedException(String message){
        super(message);
    }
}
