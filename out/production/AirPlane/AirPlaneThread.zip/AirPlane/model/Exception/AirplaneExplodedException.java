package AirPlane.model.Exception;

public class AirplaneExplodedException extends AirplaneException{
    public AirplaneExplodedException(String message){
        super(message);
    }
}
