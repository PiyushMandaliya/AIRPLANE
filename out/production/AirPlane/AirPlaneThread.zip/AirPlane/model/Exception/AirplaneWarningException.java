package AirPlane.model.Exception;

public class AirplaneWarningException extends AirplaneException {
    public AirplaneWarningException(String message) {
        super(message);
    }
}
