package AirPlane.model.Exception;

public class AirplaneDangerAltitudeException extends AirplaneException{
    public AirplaneDangerAltitudeException(String message){
        super(message);
    }
}
