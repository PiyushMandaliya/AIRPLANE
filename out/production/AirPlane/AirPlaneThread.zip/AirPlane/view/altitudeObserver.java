package AirPlane.view;

public interface altitudeObserver {
    void altitudeChanged(int currentAltitude, int targetAltitude);
}
